# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

circuits_df=spark.read.parquet(f"{processed_folder_path}/circuits").withColumnRenamed("name","circuit_name")

# COMMAND ----------

display(circuits_df)

# COMMAND ----------

races_df=spark.read.parquet(f"{processed_folder_path}/races").filter("race_year=2019").withColumnRenamed("name","race_name")

# COMMAND ----------

display(races_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Inner join just like that concept of common records from the both the table

# COMMAND ----------

races_circuits_df= circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id, "inner")

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

display(races_circuits_df.select("circuit_name"))

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Outer join- We have left outer join, right outer join, full outer join
# MAGIC

# COMMAND ----------

circuits_df = spark.read.parquet(f"{processed_folder_path}/circuits") \
    .filter("circuit_id < 70") \
    .withColumnRenamed("name","circuit_name")

# COMMAND ----------

display(circuits_df)

# COMMAND ----------

#Left outer join
races_circuits_df= circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id, "left")\
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.country,races_df.race_name,races_df.round)

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

#right outer join
races_circuits_df= circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id, "right")\
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.country,races_df.race_name,races_df.round)


# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

#Full outer join
races_circuits_df= circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id, "full")\
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.country,races_df.race_name,races_df.round)

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

# MAGIC %md 
# MAGIC Semi join _ It is similart to inner join , but you have control to only one of the columns

# COMMAND ----------

#Semi Join - Semi join will always is like inner join,but it will shown only one side of the columns not other side, as #it will throw error if we use both the columns
races_circuits_df= circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id, "semi")\
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.country)

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Anti join is opposite to semi join, it return values that does not have values

# COMMAND ----------


races_circuits_df= circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id, "anti")\
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.country)

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Cartersian join- It is a very bit rare join, where it will join the two tables and multiples like a* b= ab: It is like cross join product
# MAGIC

# COMMAND ----------

#Cross join, it will give cartesian product, where it will join left side row and right side column
races_circuits_df= races_df.crossJoin(circuits_df)

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

