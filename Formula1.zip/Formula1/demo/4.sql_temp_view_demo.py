# Databricks notebook source
# MAGIC %md
# MAGIC Objectives:
# MAGIC Create a view using sql view
# MAGIC and also using python view
# MAGIC

# COMMAND ----------

# MAGIC %run ../includes/configuration

# COMMAND ----------

race_results_df=spark.read.parquet(f"{presentation_folder_path}/races_results")

# COMMAND ----------

race_results_df.createOrReplaceTempView("v_race_results")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from v_race_results

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from v_race_results
# MAGIC where race_name="Bahrain Grand Prix"

# COMMAND ----------

# MAGIC %md
# MAGIC Global Temp View
# MAGIC Basically what is globally temporary view different from local temporary view is that in the global we can acess notebook from any of the table whereas in the local we can access from the current notebook only

# COMMAND ----------

race_results_df.createOrReplaceGlobalTempView("gv_race_results")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.gv_race_results

# COMMAND ----------

