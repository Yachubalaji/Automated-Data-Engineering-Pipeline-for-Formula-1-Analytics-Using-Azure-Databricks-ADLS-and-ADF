# Databricks notebook source
raw_folder_path='/mnt/formula1dlyachubalaji/raw'
processed_folder_path='/mnt/formula1dlyachubalaji/processed'
presentation_folder_path='/mnt/formula1dlyachubalaji/presentation'

# COMMAND ----------

