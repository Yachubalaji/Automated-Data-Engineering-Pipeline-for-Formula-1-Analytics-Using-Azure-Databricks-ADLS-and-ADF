-- Databricks notebook source
drop database if exists f1_presentation;


-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS f1_presentation
LOCATION '/mnt/formula1dlyachubalaji/presentation'