-- Databricks notebook source
-- MAGIC %md
-- MAGIC I am going to create managed database table

-- COMMAND ----------

drop database if exists f1_processed;

-- COMMAND ----------


create database if not exists f1_processed
location "/mnt/formula1dlyachubalaji/processed"


-- COMMAND ----------

desc database f1_processed;

-- COMMAND ----------

select * from f1_processed.circuits;

-- COMMAND ----------

