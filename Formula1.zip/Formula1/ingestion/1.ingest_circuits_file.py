# Databricks notebook source
# MAGIC %md
# MAGIC Read the csv file using Dataframe API reader

# COMMAND ----------

dbutils.widgets.text("p_data_source", "")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_date", "2021-03-21")
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

v_file_date

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common-functions"

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/formula1dlyachubalaji/raw

# COMMAND ----------

circuits_df= spark.read.csv(f"{raw_folder_path}/{v_file_date}/circuits.csv", header=True,inferSchema=True)

# COMMAND ----------

type(circuits_df)

# COMMAND ----------

circuits_df.show()

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

circuits_schema=StructType(fields=[StructField("circuitId", IntegerType(), False),
                                   StructField("circuitRef", StringType(), True), 
                                   StructField("name", StringType(), True), 
                                   StructField("location", StringType(), True), 
                                   StructField("country", StringType(), True), 
                                   StructField("lat", DoubleType(), True), 
                                   StructField("lng", DoubleType(), True), 
                                   StructField("alt", IntegerType(), True), 
                                   StructField("url", StringType(), True)])

# COMMAND ----------

circuits_df=spark.read.csv(f"{raw_folder_path}/{v_file_date}/circuits.csv", header=True, schema=circuits_schema)

# COMMAND ----------

circuits_df.printSchema()

# COMMAND ----------

display(circuits_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Removing Unnecessary columns and renaming columns

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %md
# MAGIC Now atlast what we are go to do next step is adding paramter,passing it and then make the parameter to display in the output

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

from pyspark.sql.functions import lit


# COMMAND ----------

circuits_paramter_df = circuits_df.withColumn("data_source", lit(v_data_source))\
                                  .withColumn("file_date", lit(v_file_date))

# COMMAND ----------

display(circuits_paramter_df)

# COMMAND ----------

circuits_selected_df= circuits_paramter_df.select(col("circuitId").alias("circuit_id"), col("circuitRef").alias("circuit_ref"), col("name"),col("location"),col("country"),col("lat").alias("latitude"), col("lng").alias("longitude"), col("alt").alias("altitude"),col("data_source"),col("file_date"))

# COMMAND ----------

display(circuits_selected_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

circuits_final_df = add_ingestion_date(circuits_selected_df)

# COMMAND ----------

display(circuits_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Now we need to move this edited file to processaed folder as parquet file

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

circuits_final_df.write.mode("overwrite").format("delta").saveAsTable("f1_processed.circuits")

# COMMAND ----------

display(circuits_final_df);

# COMMAND ----------

# MAGIC %md
# MAGIC Now atlast what we are go to do next step is adding paramter,passing it and then make the parameter to display in the output
# MAGIC

# COMMAND ----------

dbutils.notebook.exit("Sucess")