# Databricks notebook source
files = dbutils.fs.ls("/mnt/formula1dlyachubalaji/raw")
display(files)

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, IntegerType, StringType, FloatType

lap_times_schema = StructType(fields=[
    StructField("raceId", IntegerType(), False),
    StructField("driverId", IntegerType(), True),
    StructField("lap", IntegerType(),True),
    StructField("position", IntegerType(), True),
    StructField("time", StringType(), True),
    StructField("milliseconds", StringType(), True)
])

# COMMAND ----------

lap_times_df= spark.read.schema(lap_times_schema).csv("dbfs:/mnt/formula1dlyachubalaji/raw/lap_times")

# COMMAND ----------

display(lap_times_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, col,lit

# COMMAND ----------

final_parameter_df = lap_times_df.withColumnRenamed('driverId', 'driver_id') \
    .withColumnRenamed('raceId', 'race_id') \
    .withColumn("Ingestion_date", current_timestamp())

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source=dbutils.widgets.get("p_data_source")
v_data_source
final_df=final_parameter_df.withColumn("data_source", lit(v_data_source))

# COMMAND ----------

display(final_df)

# COMMAND ----------

final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.lap_times")

# COMMAND ----------

display(spark.read.parquet('/mnt/formula1dlyachubalaji/processed/lap_times'))

# COMMAND ----------

dbutils.notebook.exit("Success")

# COMMAND ----------

