# Databricks notebook source
dbutils.widgets.text("p_data_source", "")
v_data_source = dbutils.widgets.get("p_data_source")
print(f"Received data source: {v_data_source}")

# COMMAND ----------

dbutils.widgets.text("p_file_date", "2021-03-21")
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

v_file_date

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common-functions"

# COMMAND ----------

files = dbutils.fs.ls("/mnt/formula1dlyachubalaji/raw")
display(files)

# COMMAND ----------

constructor_schema= spark.read.json(f"{raw_folder_path}/{v_file_date}/constructors.json")


# COMMAND ----------

display(constructor_schema)

# COMMAND ----------

constructor_schema.printSchema()

# COMMAND ----------

constructor_schema= spark.read.option("header",True).option('inferSchema',True).json(f"{raw_folder_path}/{v_file_date}/constructors.json")


# COMMAND ----------

constructor_schema.printSchema()

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, IntegerType, StringType, DoubleType

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

constructors_schema = StructType(fields=[
    StructField("constructorId", IntegerType(), False),
    StructField("constructorRef", StringType(), True),
    StructField("name", StringType(), True),
    StructField("nationality", StringType(), True),
    StructField("url", StringType(), True)
])

# COMMAND ----------

constructor_df= spark.read.schema(constructors_schema).json(f"{raw_folder_path}/{v_file_date}/constructors.json")



# COMMAND ----------

display(constructor_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit, col, to_timestamp, concat

# COMMAND ----------

constructor_parameter_df=constructor_df.withColumn("data_source", lit(v_data_source))\
                                       .withColumn("file_date",lit(v_file_date))

# COMMAND ----------

constructor_selected_df= constructor_parameter_df.select(col("constructorId").alias("constructor_id"), col("constructorRef").alias("constructor_ref"), col("name"), col("data_source"),col("nationality"),col("file_date"))

# COMMAND ----------

display(constructor_selected_df)

# COMMAND ----------

constructor_final_df=constructor_selected_df.withColumn("Ingestion_date", current_timestamp())

# COMMAND ----------

display(constructor_final_df)

# COMMAND ----------

constructor_final_df.write.mode("overwrite").format("delta").saveAsTable("f1_processed.constructors")

# COMMAND ----------

display (constructor_final_df)

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/formula1dlyachubalaji/processed/constructors

# COMMAND ----------

dbutils.notebook.exit("Success")

# COMMAND ----------

