-- Databricks notebook source
-- MAGIC %python
-- MAGIC html= """
-- MAGIC <h1 style = "color:Black";text-align:center;font-family:Ariel>Report on Dominant Formula1 Dominant Teams</h1>"""

-- COMMAND ----------

-- MAGIC %python
-- MAGIC displayHTML(html)

-- COMMAND ----------

select team_name,
       count(1) as total_races,
       sum(calculated_points) as total_points,
       avg(calculated_points) as average_points,
       rank() over(ORDER BY avg(calculated_points) desc) as driver_rank
       from f1_presentation.calculated_race_results
group by team_name
having count(1) >=50
order by total_points desc;

-- COMMAND ----------

create or replace TEMP VIEW v_dominant_teams
as
select team_name,
       count(1) as total_races,
       sum(calculated_points) as total_points,
       avg(calculated_points) as average_points,
       rank() over(ORDER BY avg(calculated_points) desc) as team_rank
       from f1_presentation.calculated_race_results
group by team_name
having count(1) >=100
order by total_points desc;

-- COMMAND ----------

select race_year, team_name,
       count(1) as total_races,
       sum(calculated_points) as total_points,
       avg(calculated_points) as average_points
       from f1_presentation.calculated_race_results
where team_name in (select team_name from v_dominant_teams where team_rank <=10) 
group by race_year, team_name
order by race_year,total_points desc;

-- COMMAND ----------

