# Databricks notebook source
formula1dl_account_key= dbutils.secrets.get(scope="formula1dlyachubalaji-scope", key="formula1dlyachubalaji-account-key")

# COMMAND ----------

#Link the databrikcs with azure data gen 2 lake storage using access keys
spark.conf.set("fs.azure.account.key.formula1dlyachubalaji.dfs.core.windows.net", formula1dl_account_key)

# COMMAND ----------

dbutils.fs.ls("abfss://demo@formula1dlyachubalaji.dfs.core.windows.net")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlyachubalaji.dfs.core.windows.net"))

# COMMAND ----------

spark.read.csv("abfss://demo@formula1dlyachubalaji.dfs.core.windows.net/circuits.csv")

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlyachubalaji.dfs.core.windows.net/circuits.csv"))

# COMMAND ----------

