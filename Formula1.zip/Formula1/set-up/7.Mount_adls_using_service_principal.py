# Databricks notebook source
client_id= "df694c11-7428-49c1-9516-370e0e96f968"
tenant_id="4712da82-57af-43a6-b3cf-530ddfbbdaed"
client_secret="Pyk8Q~xpRAd1-~5o4SQYkn_oD_odHC~pv9j_6c6f"

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1dlyachubalaji.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.formula1dlyachubalaji.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.formula1dlyachubalaji.dfs.core.windows.net", client_id)
spark.conf.set("fs.azure.account.oauth2.client.secret.formula1dlyachubalaji.dfs.core.windows.net", client_secret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.formula1dlyachubalaji.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": client_id,
          "fs.azure.account.oauth2.client.secret": client_secret,
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}


# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://demo@formula1dlyachubalaji.dfs.core.windows.net/",
  mount_point = "/mnt/formula1dlyachubalaji/demo",
  extra_configs = configs)

# COMMAND ----------

display(dbutils.fs.ls('/mnt/formula1dlyachubalaji/demo/circuits.csv'))

# COMMAND ----------

display(spark.read.csv('/mnt/formula1dlyachubalaji/demo/circuits.csv'))

# COMMAND ----------

